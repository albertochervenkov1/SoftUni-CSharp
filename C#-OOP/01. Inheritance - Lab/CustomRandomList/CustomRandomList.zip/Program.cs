﻿using System;

namespace CustomRandomList
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            RandomList list = new RandomList();
            list.Add("Pesho");
            list.Add("Gogi");
            list.Add("Alberto");
            list.Add("Ivan");
        }
    }
}
