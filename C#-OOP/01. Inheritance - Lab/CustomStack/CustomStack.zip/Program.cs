﻿using System;
using System.Collections.Generic;

namespace CustomStack
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            StackOfStrings st = new StackOfStrings();

            st.AddRange(new List<string>()
            {
            "Alberto"

            });
        }
    }
}
