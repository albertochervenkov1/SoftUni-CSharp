﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cars.Concrats
{
    public interface IElectricCar
    {
        public int Battery { get; set; }
    }
}
