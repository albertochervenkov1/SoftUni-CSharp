﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace IteratorsAndComparator
{
    public class Library<T> : IEnumerable<Book>
        where T:Book
    {
        public Library(IEnumerable<Book> books)
        {
            this.books = new List<Book>(books);
        }
        public Library()
        {
            books = new List<Book>();
        }
        private readonly List<Book> books;

        public IEnumerator<Book> GetEnumerator()
        {
            return new LibraryIterator(this.books);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}
