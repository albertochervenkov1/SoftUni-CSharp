﻿using System;

namespace GenericArrayCreator
{
    class StartUP
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
